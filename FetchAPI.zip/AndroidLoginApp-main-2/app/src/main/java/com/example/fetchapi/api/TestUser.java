package com.example.fetchapi.api;

public class TestUser {
    private String login;
    private String pass;
    private String apiKey = "zaq!@wsx";

    public TestUser(String login, String pass) {
        this.login = login;
        this.pass = pass;
    }
}

